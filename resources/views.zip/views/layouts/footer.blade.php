
<div class="footer">
		<div class="footer-cont">
			<p>Copyright 2023 by Aitech. All Rights Reserved.</p>
		</div>
</div>





<script src="{{asset('front/js/jquery.js')}}"></script>
<script src="{{asset('front/js/jquery.steps.js')}}"></script>
<script src="{{asset('front/js/bootstrap.min.js')}}"></script>
<script src="{{asset('front/js/main.js')}}"></script>

@stack('scripts')

</body>
</html>